const sonic = document.querySelector('.sonic');
const obstaculo = document.querySelector('.obstaculo');

const jump = () => {
    sonic.classList.add('jump');

    sonic.src = './image/sonic_jump.webp'
    

    setTimeout(() => {

        sonic.classList.remove('jump');
    
        sonic.src = './image/sonic_2.gif'
    
    }, 1000);
}

const loop = setInterval(() => {

const obstaculoPosition = obstaculo.offsetLeft;
const sonicPosition = +window.getComputedStyle(sonic).bottom.replace('px', '');

if (obstaculoPosition <= 125 && obstaculoPosition > 0 && sonicPosition < 90) {

    obstaculo.style.animation = 'none';
    obstaculo.style.left = '${obstaculoPosition}px';

    /*sonic.src = './image/sonic_jump.webp'*/

    sonic.style.animation = 'none';
    sonic.style.bottom = '${sonicPosition}px';

    sonic.src = './image/sonic_game_over.png'


    clearInterval(loop);
}

}, 10);

document.addEventListener('keydown', jump);

